#Load Data
data(mtcars)
mtcars

#Create Dataset
input <- mtcars[,c("mpg","disp","hp","wt")]
print(head(input))

#Multi-Reg Model
model <- lm(mpg~disp+hp+wt, data = input)
summary(model)

#Predict
newdata = data.frame(disp=150, hp=100, wt=2.7)
predict(model, newdata) 


#Multi-Reg Model on all variables
mtcars
model2 <- lm(mpg~., data = mtcars)
print(model2)

summary(model2)

