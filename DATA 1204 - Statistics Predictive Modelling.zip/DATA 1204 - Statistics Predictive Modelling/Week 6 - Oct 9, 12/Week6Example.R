#Central Limit Theorem Notes
#EXAMPLE 1 - fair die
#Expected Value (1+2+3+4+5+6)/6 = 3.5
#Throw die 10,000 times, plot frequency
DieOutcome <- sample (1:6, 10000, replace = TRUE)
hist(DieOutcome, col = "light blue")
abline(v=3.5, col = "red", lty = 1)

#Take Sample size of 10, take arithmetic mean and plot mean of sample
#Do procedure 10,000 times (k=10000)
x10 <- c()
k = 10000 
for (i in 1:k) {
  x10[i] = mean(sample(1:6,10, replace = TRUE))}
hist(x10, col="pink", main="Sample size =10", xlab="Outcome of die roll")
abline(v = mean(x10), col = "Red")
abline(v = 3.5, col = "blue")

#In theory, as n approaches infinity, they get a normal distribution
#Increase sample size to 30, 100, and 1000
x30 <- c()
x100 <- c()
x1000 <- c()
k =10000
for ( i in 1:k){
  x30[i] = mean(sample(1:6,30, replace = TRUE))
  x100[i] = mean(sample(1:6,100, replace = TRUE))
  x1000[i] = mean(sample(1:6,1000, replace = TRUE))
}
par(mfrow=c(1,3))
hist(x30, col ="green",main="n=30",xlab ="die roll")
abline(v = mean(x30), col = "blue")

hist(x100, col ="light blue", main="n=100",xlab ="die roll")
abline(v = mean(x100), col = "red")

hist(x1000, col ="orange",main="n=1000",xlab ="die roll")
abline(v = mean(x1000), col = "red")

