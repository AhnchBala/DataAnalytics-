#Import Libraries
library(mosaic)
library(mosaicData)
library(mosaicCore)

#PART A
#Question 1
tally(~smoker + outcome, data = Whickham, format = "proportion")

#Question 2
tally(~smoker + age, data = Whickham, format = "proportion")

