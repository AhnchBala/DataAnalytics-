#Uniform Distribution - has a constant probability
#Load library
library(ggplot2)

data_uniform = runif(n=10000, min=0, max=10)
ggplot() + aes(x=data_uniform) + geom_histogram(bins=100, fill="magenta1")

#Normal Distribution - Bell Shaped
#mean = 0, std = 1
#Z-score = number of standard deviations it falls above or below mean -> z = (score - population mean)/population std
data_normal = rnorm(100000, mean=0, sd=1)
ggplot() + aes(x=data_normal) + geom_histogram(bins=100, fill="magenta1")

#Bernoulli Distribution - discrete probability distribution with two possible outcomes (eg. heads/tails)
data_bernoulli = (rbinom(p=0.5, size=1, n=10000))
ggplot() + aes(x=data_bernoulli) + geom_histogram(bins=100, fill="magenta1")

#Binomial Distribution - # of successes over a given number of trials
#eg. if we toss a coin 10 times, what is the probability of seeing 8 heads
data_binomial = rbinom(p=0.5, size=10, n=10000)
ggplot() + aes(x=data_binomial) + geom_histogram(bins=100, fill="magenta1")

#Negative Binomial Distribution - estimate number of tries before reaching a specific number of successes
#eg. flipping a coin until it lands on heads twice - the negative binomial random variable is number of times it takes to see this result
data_negbinomial = rnbinom(p=0.5, size=10, n=10000)
ggplot() + aes(x=data_negbinomial) + geom_histogram(bins=100, fill="magenta1")

#Poisson Distribution - likelihood a number of events occurs within time interval
#key parameter - average number of events in given interval
data_poisson = rpois(n=10000,lambda = 3)
ggplot() + aes(x=data_poisson) + geom_histogram(bins=100, fill="magenta1")

#Geometric Distribution - likelihood of first success to occur
#eg. 50% change heads on first try, 25% chance heads on second try, 12.5% chance heads on third try, etc.
data_geometric = (rgeom(n=10000,p=0.5))
ggplot() + aes(x=data_geometric) + geom_histogram(bins=100, fill="magenta1")

#Inspecting Histogram and Normal Curve Fit
#Quantile-Quantile plot (QQ Plot) - correlation between sample and normal distribution

#Store data in variable my_data
my_data <- ToothGrowth
my_data

#Create QQ Plot
qqnorm(my_data$len, pch=1, xlab = "Theoretical Quantiles", ylab = "Sample Quantiles")
qqline(my_data$len, col = "steelblue", lwd = 2)

#Fitting a Normal Distribution Curve
#Histogram with Normal Curve
histNC <- ggplot(my_data, aes(x=my_data$len))
histNC <- histNC + geom_histogram(binwidth=2, color = "black", aes(y=..density..,fill=..count..))
histNC <- histNC + scale_fill_gradient("Count", low="light blue", high="blue")
histNC <- histNC + stat_function(fun=dnorm, color="red", args = list(mean=mean(my_data$len), sd=sd(my_data$len)))

histNC
