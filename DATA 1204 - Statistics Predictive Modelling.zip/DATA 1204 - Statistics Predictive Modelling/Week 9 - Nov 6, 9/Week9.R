#1-sample proportions test without continuity correction
prop.test(36,50,p=0.5,correct=FALSE)

#2-sample test for equality of proportions without continuity correction
prop.test(x=c(9,4),n=c(29,31), conf.level=0.95, correct=FALSE)
