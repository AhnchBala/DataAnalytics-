#QUESTION 1
#1-sample proportions test without continuity correction
prop.test(447,998,p=0.3,correct=FALSE)

#QUESTION 2
#2-sample test for equality of proportions without continuity correction
prop.test(x=c(30,65),n=c(74,103), conf.level=0.95, correct=FALSE)