#Load Library
library(dplyr)
library(psych)

#Load Data
data.ex1=alertness

#Review Key Statistics
describe(data.ex1)

#One-Way ANOVA Test
# The first argument is always the dependent variable.
aov.ex1 = aov(Alertness~Dosage,data=data.ex1)  
summary(aov.ex1)


#Two-way Anova
my_data <- ToothGrowth
my_data

# Convert dose as a factor and recode the levels  as "D0.5", "D1", "D2"
my_data$dose <- factor(my_data$dose, 
                       levels = c(0.5, 1, 2),
                       labels = c("D0.5", "D1", "D2"))
head(my_data)

#Two way Anova Model
fitTooth <- aov(len ~ supp + dose, data = my_data)
summary(fitTooth)
