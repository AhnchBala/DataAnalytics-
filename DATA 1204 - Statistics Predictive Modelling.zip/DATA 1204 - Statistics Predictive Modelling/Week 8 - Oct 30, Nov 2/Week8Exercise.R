#Load Library
library(dplyr)
library(psych)

#Load Data
data.ex1=alertness

#Review Key Statistics
describe(data.ex1)
