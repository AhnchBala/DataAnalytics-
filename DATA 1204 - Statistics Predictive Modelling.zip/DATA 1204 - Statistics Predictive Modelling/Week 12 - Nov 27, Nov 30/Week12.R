#Simple Regression Model
simple.fit<-lm(Sales~Spend, data=mktgbudget)
LinearModel<-simple.fit
summary(LinearModel)

#Prediction
newdata = data.frame(Spend=10000) # create new data set
predict(LinearModel, newdata)    # apply predict function 