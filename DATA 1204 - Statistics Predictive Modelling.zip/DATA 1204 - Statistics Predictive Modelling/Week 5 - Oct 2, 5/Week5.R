#Load Libraries
install.packages("openintro")
library(openintro)

View(satGPA) # shows the entire database in the top left section of RStudio
head(satGPA) #returns the first few rows of the dataset
str(satGPA) # reports key information about the dataset (observations, variables, etc.)

#Calculate z parameters
mu <- mean(satGPA$SATM) #mean
mu

sd <- sd(satGPA$SATM) #standard deviation
sd

#Want to test the hypothesis that national average SAT score in mathematics is 50%, significance level = 5%
#Use sample standard deviation
#Null Hypothesis -> standard national average mu = 50
#Alternate Hypothesis -> standard national average mu =/= 50 (two tail)

mu0 <- 50            # Specify the mean
alpha <- 0.05        # Specify the significance level
sigma <- 8.45        # population standard deviation

n <- nrow(satGPA)    # get the sample size

#Calculate z statistic
z<-(mu-mu0)/(sigma/sqrt(n))
z

#Calculate p-value
2*pnorm(abs(z),lower.tail = FALSE) # p-values (we multiple the function by 2 since it's a two-side test) 

#Since p value is less than 0.05 confidence interval, REJECT null hypothesis that mu = 50
#Reject that population average (SAT math percentile) is 50. We don't know what it is, but we reject that it is 50
