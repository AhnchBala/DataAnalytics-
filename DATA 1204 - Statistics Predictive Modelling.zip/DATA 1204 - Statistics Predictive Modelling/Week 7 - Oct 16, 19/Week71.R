library(mosaic)
#One Sample T-test
sample = c(65, 78, 88, 55, 48, 95, 66, 57, 79, 81)
histogram(sample,fit="normal")
summary(sample)

sample

#2-tail
t.test(sample, mu=75)

#1-tail
t.test(sample, mu=75,alternative = "less")
t.test(sample, mu=75,alternative = "greater")

#Paired T-test
Sampleafter= c(12.9, 13.5, 12.8, 15.6, 17.2, 19.2, 12.6, 15.3, 14.4, 11.3)
Samplebefore= c(12.7, 13.6, 12.0, 15.2, 16.8, 20.0, 12.0, 15.9, 16.0, 11.1)
t.test(Sampleafter,Samplebefore, paired=TRUE)

#Two Sample T-test
testa=c(175,168,168,190,156,181,182,175,174,179)
testb=c(185,169,173,188,186,175,174,179,180)
t.test(testa,testb, var.equal=TRUE, paired=FALSE)

#Power
install.packages("pwr")
library(pwr)
p.out <- pwr.p.test(h = ES.h(p1 = 0.75, p2 = 0.50),sig.level = 0.05, power = 0.80,                  alternative = "greater")
plot(p.out)
