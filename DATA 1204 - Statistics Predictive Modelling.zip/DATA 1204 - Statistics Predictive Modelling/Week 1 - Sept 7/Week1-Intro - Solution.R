# Simple Math
5 + 3 
15.3 * 23.4
sqrt(16)

# Creating functions
product = 15.3 * 23.4     # save result
product     		   # display the result

product <- 15.3 * 23.4     # <- can be used instead of =
product                    # display the result

#Clear workspace
rm(list = ls())
