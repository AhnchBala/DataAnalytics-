# Simple Math
5+3
15.3*23.4
sqrt(16)

#Creating Functions
product = 15.3 * 23.4 # Save result
product # Display the result

product <- 15.3 * 23.4 # <- Can be used instead of =, this notation is proper R Coding (not using the = sign)
product

#Clear workspace
rm(list = ls()) # Clears memory
