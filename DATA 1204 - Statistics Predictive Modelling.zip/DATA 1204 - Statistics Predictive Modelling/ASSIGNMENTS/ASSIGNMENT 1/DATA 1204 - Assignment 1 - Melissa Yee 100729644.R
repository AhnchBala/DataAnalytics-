#Load Data Using Import Data Set Function
#View DataSet
adanalysis

#Load Libraries
library(openintro)

#Calculate mean and standard error (z-score parameters)
mean.ad <- mean(adanalysis$adtype2)
sd.ad <- sd(adanalysis$adtype2)
SE.ad <- sd.ad / sqrt(length(adanalysis$adtype2))

#Show all calculated metrics
mean.ad
sd.ad
SE.ad

#Since Samsung wants to know if average weekly sales is 30,000 this is a two-tail test
#If Null Hypothesis is rejected, then average sales is not equal to 30,000

#State Ho
Ho <- 30000

#Calculate Z-score
z <- (mean.ad - Ho)/SE.ad
z

#Two-Tail Test
2*pnorm(abs(z), lower.tail = FALSE)
