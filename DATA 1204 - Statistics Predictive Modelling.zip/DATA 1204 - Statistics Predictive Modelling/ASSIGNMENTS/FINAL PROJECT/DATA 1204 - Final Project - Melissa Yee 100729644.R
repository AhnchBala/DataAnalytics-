#Load Dataset using Import Dataset Function

#Basic Statistics of Data
summary(winequality)

#Standard Deviations of variables: quality, fixed acidity, pH, and alcohol
sd(winequality$quality)
sd(winequality$`fixed acidity`)
sd(winequality$pH)
sd(winequality$alcohol)

#GRAPHS
#Load Library
library(ggplot2)

#Quality Distribution
ggplot(data=winequality, aes(x = quality)) + geom_bar(color = "pink", fill = "pink") + 
  labs(title = "Wine Quality Distribution",
       x = "Wine Quality",
       y = "Number of Records") + 
  theme(plot.title = element_text(hjust=0.5))

#Alcohol vs. Quality Scatterplot
ggplot(data=winequality,aes(x = alcohol, y = quality, color = alcohol)) + geom_point() + 
  labs(title="Scatter Plot of Alcohol vs. Quality") + 
  theme(plot.title = element_text(hjust = 0.5)) + xlab('Alcohol Percentage') + ylab('Wine Quality') +
  scale_color_gradient(low="blue", high="red")

#Fixed Acidity vs. pH Scatterplot with Trend Line
ggplot(data=winequality,aes(x = pH, y = `fixed acidity`, color = pH)) + geom_point() + 
  labs(title="Scatter Plot of pH vs. Fixed Acidity") + 
  theme(plot.title = element_text(hjust = 0.5)) + xlab('pH') + ylab('Fixed Acidity (mg/L)') +
  geom_smooth(method="lm", color = "black") +
  scale_color_gradient(low="red", high="yellow")


#T-TESTING
#Two-tail T-test conducted to determine if mean wine quality = 5.6
#Ho: mean = 5.6
#Ha: mean =/= 5.6
#Need To test for wine quality column

#Extract quality column from Dataset to use for T-Test
#Also converts column to array & Show Dataset
quality <- winequality[['quality']]
quality

#Conduct T-test
t.test(quality, mu=5.6)
#p-value > 0.05, accept Ho, therefore mean quality = 5.6


#LINEAR REGRESSION

#Confirm linear relationship with normalized data
cor(sqrt(winequality$quality), sqrt(winequality$alcohol))

#Simple Regression Model with normalized data
simple.fit<-lm(sqrt(quality)~sqrt(alcohol), data=winequality)
LinearModel<-simple.fit
summary(LinearModel)


#MULTIPLE LINEAR REGRESSION
#Create Multiple Linear Model
model <- lm(quality~., data = winequality)
summary(model)
