#Import Dataset using Import Function

#Simple Regression Model
simple.fit<-lm(stock_return_scaled~dividend, data=ols_stock)
LinearModel<-simple.fit
summary(LinearModel)


#Simple Regression Model
simple.fit<-lm(stock_return_scaled~stock_return, data=ols_stock)
LinearModel<-simple.fit
summary(LinearModel)


#Simple Regression Model
simple.fit<-lm(stock_return_scaled~marketcap, data=ols_stock)
LinearModel<-simple.fit
summary(LinearModel)
