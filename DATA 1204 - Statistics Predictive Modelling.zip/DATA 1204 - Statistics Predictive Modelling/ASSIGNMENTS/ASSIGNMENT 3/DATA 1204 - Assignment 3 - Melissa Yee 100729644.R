#Install Packages and Load Libraries
install.packages("MASS")
library(MASS)       
install.packages("descr")
library(descr)

#Import Dataset Using Import Function

#Number of Cylinders vs Type
Cyltbl = table(carsdatabase$Cylinders, carsdatabase$Type) 
Cyltbl
chisq.test(Cyltbl) 

#Number of Cylinders vs Type Cross Tabulation
crosstab(carsdatabase$Cylinders, carsdatabase$Type, prop.r=TRUE, 
         prop.c=TRUE,prop.chisq = TRUE, chisq = TRUE, row.labels = TRUE)

#Horsepower vs Type Chi Squared
Hptbl = table(carsdatabase$Horsepower, carsdatabase$Type) 
Hptbl
chisq.test(Hptbl) 

#Horsepower vs Type Cross Tabulation
crosstab(carsdatabase$Horsepower, carsdatabase$Type, prop.r=TRUE, 
         prop.c=TRUE,prop.chisq = TRUE, chisq = TRUE, row.labels = TRUE)

#Make vs Type
mktbl = table(carsdatabase$Make, carsdatabase$Type) 
mktbl
chisq.test(mktbl)

#Make vs Type Cross Tabulation
crosstab(carsdatabase$Make, carsdatabase$Type, prop.r=TRUE, 
         prop.c=TRUE,prop.chisq = TRUE, chisq = TRUE, row.labels = TRUE)
