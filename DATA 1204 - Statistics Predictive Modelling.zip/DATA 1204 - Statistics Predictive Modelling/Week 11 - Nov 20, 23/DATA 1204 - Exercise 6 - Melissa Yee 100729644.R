#Load Libraries
library(dplyr)
library(ggplot2)

#Load Dataset using Import Dataset Function

#Plot Relationship between sweetness and pectin
ggplot(orangejuice,aes(x = orangejuice$Sweetness, y = orangejuice$Pectin)) + geom_point(colour = "orange") + 
  labs (title = "Orange Juice Sweetness vs Pectin", x="Sweetness", y = "Pectin")

#Plot Relationship with Line (adjusted)
ggplot(orangejuice,aes(x = orangejuice$Sweetness, y = orangejuice$Pectin)) + geom_point(colour = "orange") + geom_smooth(method = "lm", fill = NA) + 
  labs (title = "Orange Juice Sweetness vs Pectin", x="Sweetness", y = "Pectin")

#Check Correlation
cor(orangejuice$Sweetness,orangejuice$Pectin)

#Check Correlation with Transformation
cor(sqrt(orangejuice$Sweetness),sqrt(orangejuice$Pectin))

#Linear Model
lmodel <- lm(sqrt(orangejuice$Sweetness) ~ sqrt(orangejuice$Pectin), data = orangejuice)
summary(lmodel)
