#Load Libraries
library(dplyr)
library(ggplot2)

str(mtcars)

#Plot of Data set
ggplot(mtcars,aes(x = mtcars$disp, y = mtcars$mpg)) + geom_point(colour = "red")

#Correlation
cor(mtcars$disp, mtcars$mpg)
cor(sqrt(mtcars$disp), sqrt(mtcars$mpg))

#Plot with Line (adjusted)
ggplot(mtcars, aes(x = sqrt(mtcars$disp), y = sqrt(mtcars$mpg))) + geom_point(colour = "red") + geom_smooth(method = "lm", fill = NA)

#Linear Model
lmodel <- lm(sqrt(mpg) ~ sqrt(disp), data = mtcars)
summary(lmodel)
