#Load Libraries
install.packages("MASS")
library(MASS)       

#Chi-Squared Table
tbl = table(survey$Smoke, survey$Exer) 
tbl                  
chisq.test(tbl) 

#Using Crosstabs

#View Cars93 Dataset
print(str(Cars93))

install.packages("descr")
library(descr)
crosstab(Cars93$AirBags,Cars93$Type, prop.r=TRUE, 
         prop.c=TRUE,prop.chisq = TRUE, chisq = TRUE, row.labels = TRUE)


