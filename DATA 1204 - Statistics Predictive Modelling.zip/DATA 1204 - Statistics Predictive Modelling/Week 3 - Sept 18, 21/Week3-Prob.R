# Generate 10 separate random flips with probability .3
rbinom(10,1,.3)

# Generate 100 occurrences of flipping 10 coins, each with 30% probability
rbinom(100,10,.3)

# Calculate the probability that 2 are heads using dbinom
dbinom(2,10,.3)

# Calculate the probability that at least five coins are heads
1-pbinom(4,10,.3)

# Calculate the expected value using the exact formula
25*.3

# Confirm with a simulation using rbinom
mean(rbinom(10000,25,.3))

# Simulate 100,000 flips of coin A, B, C (40%, 2%, 70% chance of heads respectively)
A <- rbinom(100000, 1, .4)
B <- rbinom(100000, 1, .2)
C <- rbinom(100000, 1, .7)

# Estimate the probability A, B, and C are all heads
mean(A&B&C==1)

#Probability with Replacement

candy = c("blue","green","red")
sample(candy, size=20, replace=T)

#With defined probabilities 
sample(candy, size=20, replace=T, prob=c(0.7, 0.2, 0.1))

#A second time
sample(candy, size=20, replace=T, prob=c(0.7, 0.2, 0.1))

#Probability without Replacement
sample(candy, size=3, replace=F)

#With defined probabilites
sample(candy, size=3, replace=F, prob=c(0.7, 0.2, 0.1))


