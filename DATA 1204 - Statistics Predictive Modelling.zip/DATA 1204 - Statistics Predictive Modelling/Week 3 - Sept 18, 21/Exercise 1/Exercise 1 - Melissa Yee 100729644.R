#Load library
library(ggplot2)

#Load Data Using Import Data Set Function

#Scatterplot of Blue Jays Score vs Opponents Score
ggplot(data = BlueJaysdataset, aes(x=BlueJaysdataset$'Blue Jays Score', y=BlueJaysdataset$'Opponent Score')) + geom_point() + 
  labs (title = "Blue Jays Score vs Opponents Score from April to June 2017", x="Blue Jays Score", y = "Opponent Score")

#Histogram of Blue Jays' Score
ggplot(data = BlueJaysdataset, aes(x=BlueJaysdataset$'Blue Jays Score')) + geom_histogram() + 
  labs (title = "Histogram of Blue Jays Scores from April to June 2017", x="Blue Jays Score", y = "Count")

#Histogram of Opponents' Score
ggplot(data = BlueJaysdataset, aes(x =BlueJaysdataset$'Opponent Score')) + geom_histogram() + 
  labs (title = "Histogram of Opponent Scores from April to June 2017", x="Opponent Score", y = "Count")
