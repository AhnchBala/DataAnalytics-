#Load Library
library(mosaic)

dice = 1:6
sample(x = dice, size = 1, replace = TRUE)

dice.roll <- sample(1:6, size = 2, replace = TRUE)
dice.roll

marbles = c('red', 'blue', 'green')
sample(x = marbles, size = 2, replace = FALSE)
