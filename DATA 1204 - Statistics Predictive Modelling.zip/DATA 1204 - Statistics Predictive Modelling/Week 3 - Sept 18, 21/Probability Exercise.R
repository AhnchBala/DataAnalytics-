#Import Library
library(mosaic)

#Rolling the Dice
dice = 1:6
sample(x=dice, size=10, replace = TRUE)

#Marbles out of Bag
marbles = c('red','blue','green')
sample (x = marbles, size = 2, replace = FALSE)
