#Simulating Coin Flips - Simulate 10 coin flips, each with probability of 30% of showing heads
#Generate 10 separate random flips with probability .3 - heads = 1, tails = 0
rbinom(10,1,.3)

#Generate 100 occurences of flipping 10 coins, each with 30% probaility
rbinom(100,10,.3)

#CALCULATING DENSITY OF A BINOMIAL
#Calculate the probability that exactly 2 coins will be heads in 10 coin flips
dbinom(2,10,.3)

#CALCULATING CUMULATIVE DENSITY OF A BINOMIAL
#Calculate the probability that at least 5 coins will be heads in 10 coin flips
1-pbinom(4,10,.3)

#CALCULATING EXPECTED VALUE
#Calculated the expected value of a binomial density where 25 coins are flipped (30% heads), using exact formula
25*.3

#Confirm with simulation using rbinom
mean(rbinom(10000,25,.3))

#SIMULATING PROBABILITY OF A,B,C
#Simulates 100,000 flips of coins A,B,C (40%,20%,70% chance of heads respectively)
A <- rbinom(100000,1,.4)
B <- rbinom(100000,1,.2)
C <- rbinom(100000,1,.7)

#Estimate probability A, B, and C are all heads
mean(A&B&C==1)

#SIMULATING PROBABILITY WITH REPLACEMENT
#Probability with replacement for M&Ms (Blue, Green and Red), 20 candies
candy = c("blue","green","red")
sample(candy, size=20, replace=T)

#With Defined Probabilities (ie. there are more of a certain colour)
sample(candy, size = 20, replace = T,prob=c(0.7,0.2,0.1))

#A second time
sample(candy, size = 20, replace = T,prob=c(0.7,0.2,0.1))

#Above code can be used by setting replace = F (no replacement) - size is limited to max of population
#Probability without replacement
sample(candy,size=3,replace=F)

#With defined probabilities
sample(candy,size=3,replace=F, prob = c(0.7,0.2,0.1))
