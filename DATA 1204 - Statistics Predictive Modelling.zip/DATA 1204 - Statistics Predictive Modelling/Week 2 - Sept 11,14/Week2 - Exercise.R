# Install packages - once they are installed, you never need to install them again
#install.packages("mosaicCore")
#install.packages("mosaicData")
#install.packages("lattice")
#install.packages("psych")

#Import Libraries
library(mosaic)
library(mosaicData)
library(mosaicCore)
library(lattice)
library(psych)

#Set precision to 3 digits
options(digits=3)

#Load Dataset
HELPrct

#SUMMARY STATISTICS

# $ - looking for a specific column/variable, this is then looking for the cesd column in the dataset

#Mean
mean(HELPrct$cesd)
#Standard Deviation
sd(HELPrct$cesd)
#Variance
var(HELPrct$cesd)
#Median
median(HELPrct$cesd)

#Basic Statistics using Describe
describe(HELPrct$cesd)

#Box Plot
# main is the title, xlab = x-axis label, ylab = y-axis label
boxplot(mcs~cesd,data=HELPrct,main="Epidemiologic studies",xlab="cesd",ylab="msc")

#Histograms
#fit = normal to set a normal distribution curve
histogram(HELPrct$cesd,fit="normal")

#Scatterplot with line
plot(HELPrct$mcs,HELPrct$cesd) #this creates the scatterplot
abline(lm(HELPrct$mcs~HELPrct$cesd),col="red") #this creates the line, and colours it red

#Correlations
cor(HELPrct$mcs,HELPrct$cesd,use="complete.obs")

#Normal Distribution Graph
xpnorm(1.96,mean=0,sd=1)

#Quick Tally of Information
tally(~homeless,data=HELPrct)
tally(~homeless+sex,margins=FALSE,data=HELPrct)
