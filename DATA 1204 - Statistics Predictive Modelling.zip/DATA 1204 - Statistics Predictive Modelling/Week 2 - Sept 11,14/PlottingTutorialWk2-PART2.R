#Load Library
library(ggplot2)

#Load Data
data(mtcars)

#Display Data
mtcars

#Scatter Plot
#mpg assigned to x axis, hp assigned to y axis
#factor(cyl) = number of cylinders, determines colour
ggplot(data=mtcars, aes(x=mpg, y=hp, col=factor(cyl))) + geom_point() + 
  labs(title = "Scatter Plot MPG and HP") + 
  theme(plot.title = element_text(hjust=0.5))

#From looking at graph can see:
#As MPG increases, HP decreases
#4 cylinder cars have highest MPG and lowest HP
#6 cylinder cars have HP in range of 100-175, MPG in range of 17.5-22.5
#8 cylinder cars have lowest HP and highest MPG


#Scatter Plot with Smooth Line
#Assigns wt (weight 1000), to x axis and MPG to y axis
#stat_smooth plots a smoothed version of data
#theme() centers plot title
ggplot(data=mtcars,aes(x = wt, y = mpg)) + geom_point() + 
  stat_smooth(method='lm') + 
  labs(title="Scatter Plot MPG and HP with Smoothing") + 
  theme(plot.title = element_text(hjust = 0.5)) + xlab('Weight(1,000)') + ylab('MPG')

#Stacked Bar Chart
#Assigns number of cylinders to x axis
#factor(gear) = number of gears, determines colour of bars
ggplot(data=mtcars,aes(x=cyl, fill=factor(gear))) + geom_bar() + 
  labs(title="Histogram CYL by Gear") + 
  theme(plot.title = element_text(hjust=0.5))

#From Looking at graph can see:
#If a car is 4 cylinders, it would probably have 4 forward gears
#Most 6 cylinder cars have 4 forward gears, followed by 3 and 5
#No 8 cylinder car has 4 forward gears, most have 3


#Stacked Bar Chart - proportioned
#Position = fill gives bar plot in terms of proportion
ggplot(data=mtcars,aes(x=cyl, fill=factor(gear))) + geom_bar(position = "fill") + 
  labs(title = "Histogram CYL by Gear (Porportion") + 
  theme(plot.title = element_text(hjust=0.5))

#Box Plot
#cyl (number of cylinders) assigned to x axis, mpg assigned to y axis
ggplot(data=mtcars,aes(factor(cyl),mpg)) + geom_boxplot(aes(fill=factor(cyl))) + 
  labs(title = "BoxPlot Cyl vs MPG") + 
  theme(plot.title = element_text(hjust=0.5))
