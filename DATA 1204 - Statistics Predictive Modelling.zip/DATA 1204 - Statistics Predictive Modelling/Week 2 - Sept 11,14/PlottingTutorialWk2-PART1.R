#Install Package
install.packages("ggplot2")

#Load Library
library(ggplot2)

#Load Data
data(mpg)

#Display Data
mpg

#Display Scatterplot, maps cars to a color characteristic
#aes function used to all aesthetics for a plot
ggplot(data=mpg, aes(x = displ, y = hwy, color = class)) + geom_point()

#Adding color = blue, causes visual channel to be mapped from vector c("blue")
ggplot(data=mpg, aes(x = displ, y = hwy)) + geom_point(color = "blue")


#SPECIFYING GEOMETRIC SHAPES
#geoms = geometric objects, ggplot2 supports number of different types of geoms - leverages aesthetic
#mappings supplied
#eg. can map data to SHAPE of a GEOM_POINT (eg. cirlces/squres)
#Almost all geoms require x & y mapping

#Left column: x and y mapping needed
ggplot(data=mpg, aes(x = displ, y = hwy)) + geom_point() #Scatter plot
ggplot(data=mpg, aes(x = displ, y = hwy)) + geom_smooth() #Smooth line


#Right column: no y mapping needed
ggplot(data=mpg, aes(x = class)) + geom_bar() #Bar chart
ggplot(data=mpg, aes(x = hwy)) + geom_histogram() #Histogram

#Can add multiple geometries to a plot - can show multiple aspects of data at once
#eg. lm, glm, loess, rlm -> "loess" is default value and computers smooth local regression
# "lm" fits linear model

#Plot with both points AND smoothed line
ggplot(data=mpg, aes(x = displ, y = hwy)) + geom_point() + geom_smooth()

#Aesthetics for each geom can be different - show multiple lines on same plot with diff colours, styles, etc.
#Plot both points and smooth lined, specified with unique colours within each geom
ggplot(data=mpg, aes(x = displ, y = hwy)) + geom_point(color = "blue") + geom_smooth(color = "red")

#Colour aesthetic passed to each geom layer
#By setting se = FALSE, confidence shading not shown
ggplot(data=mpg, aes(x = displ, y = hwy, color = class)) + geom_point() + geom_smooth(se=FALSE)

#Colour aesthetic specified for only the geom_point layer
ggplot(data=mpg, aes(x = displ, y = hwy)) + geom_point(aes(color = class)) + geom_smooth(se=FALSE)


#POSITION ADJUSTMENTS
#default position adjustment which specifies set of "rules" as to how diff components should be positioned
#relative to each other

#Bar chart of class, coloured by drive (front, rear, 4-wheel)
ggplot(data=mpg, aes(x=class, fill = drv)) + geom_bar() #notice that this bar chart doesn't need a y value

#geom_bar uses default position as stack, makes rectangle's height proportional to its values and stacks them
#can use position argument to specify what position adjustment rules to follow

#position = "dodge" : values next to each other
ggplot(data=mpg, aes(x = class, fill = drv)) + geom_bar(position = "dodge")

#position = "fill" : percentage chart
ggplot(data=mpg, aes(x = class, fill = drv)) + geom_bar(position = "fill")


#LABELS AND ANNOTATIONS
#can add titles/axis labels using labs() - labels is a different R function

#Scatter plot with titles, subtitles and axes labeled
ggplot(data=mpg, aes(x = displ, y = hwy, color = class)) + geom_point() + 
  labs(title = "Fuel Efficiency by Engine Power",
       subtitle = "Fuel economy data from 1999 and 2008 for 38 models of cars",
       x = "Engine Power (Litres Displacement)",
       y = "Fuel Efficiency (Miles per Gallon)",
       colour = "Car Type")

#Can Export graphs (Export -> img,pdf, etc.)

#Side by Side Graphs
install.packages("cowplot")
library(cowplot)

dodgeplot <-ggplot(data=mpg, aes(x=class, fill = drv)) + geom_bar(position = "dodge")
fillplot<- ggplot(data=mpg, aes (x = class, fill = drv)) + geom_bar(position = "fill")
plot_grid(dodgeplot, fillplot, labels = c('Dodge', 'Fill'), align = "h")