#Import Libraries
library(mosaic)
library(mosaicCore)
library(mosaicData)
library(lattice)
library(psych)

#Load dataset
HELPrct

#Set output to 3 digits
options(digits=3)

#Basic Statistics
mean(HELPrct$cesd)
sd(HELPrct$cesd)
var(HELPrct$cesd)
median(HELPrct$cesd)

#Using Describe for Basic Statistics
describe(HELPrct$cesd)

#Box Plot
boxplot(mcs~cesd,data=HELPrct,main=" Epidemiologic studies",xlab="cesd", ylab="mcs")

#Histogram
histogram(HELPrct$cesd,fit="normal")

#Plot with Line
plot(HELPrct$mcs,HELPrct$cesd)
abline(lm(HELPrct$mcs~HELPrct$cesd),col="red")

#Correlation
cor(HELPrct$mcs,HELPrct$cesd, use="complete.obs") 

#Normal Distrubtion
xpnorm(1.96,mean=0,sd=1)

#Tally of Information
tally(~homeless, data=HELPrct)
tally(~homeless+sex,margins=FALSE, data=HELPrct)
