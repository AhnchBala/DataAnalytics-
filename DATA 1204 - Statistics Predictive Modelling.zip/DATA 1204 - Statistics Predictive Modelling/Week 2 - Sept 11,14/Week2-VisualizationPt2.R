#Week #2 - Graphing Tutorial

#Part I

#Load Library
library(ggplot2)

#Load Data
data(mpg)
mpg

#Using aes function
ggplot(data=mpg, aes(x = displ, y = hwy, color = class)) + geom_point()
ggplot(data=mpg, aes(x = displ, y = hwy)) + geom_point(color = "blue")

# Left column: x and y mapping needed!
ggplot(data=mpg, aes(x = displ, y = hwy)) +  geom_point()
ggplot(data=mpg, aes(x = displ, y = hwy)) +  geom_smooth()

# Right column: no y mapping needed!
ggplot(data = mpg, aes(x = class)) +  geom_bar(color="red", fill='black')
ggplot(data = mpg, aes(x = hwy)) +  geom_histogram(color="red", fill='black',binwidth = 1) 

# plot with both points and smoothed line
ggplot(data=mpg, aes(x = displ, y = hwy)) +
  geom_point() +
  geom_smooth()

# plot with both points and smoothed line (color)
ggplot(data=mpg, aes(x = displ, y = hwy)) +
  geom_point(color = "blue") +
  geom_smooth(color = "red")

# color aesthetic passed to each geom layer
ggplot(data=mpg, aes(x = displ, y = hwy, color = class)) +
  geom_point() +
  geom_smooth(se = FALSE)

# color aesthetic specified for only the geom_point layer
ggplot(data=mpg, aes(x = displ, y = hwy)) +
  geom_point(aes(color = class)) +
  geom_smooth(se = FALSE)

# bar chart of class, colored by drive (front, rear, 4-wheel)
ggplot(data=mpg, aes(x = class, fill = drv)) + 
  geom_bar()

# position = "dodge": values next to each other
ggplot(data=mpg, aes(x = class, fill = drv)) + 
  geom_bar(position = "dodge")

# position = "fill": percentage chart
ggplot(data=mpg, aes(x = class, fill = drv)) + 
  geom_bar(position = "fill")

#Labeling
ggplot(data=mpg, aes(x = displ, y = hwy, color = class)) +
  geom_point() +
  labs(title = "Fuel Efficiency by Engine Power",
       subtitle = "Fuel economy data from 1999 and 2008 for 38 popular models of cars",
       x = "Engine power (litres displacement)",
       y = "Fuel Efficiency (miles per gallon)",
       color = "Car Type")

#PartII

#Load Data
data(mtcars)
mtcars

#Scatterplot
ggplot(data = mtcars,aes(x=mpg,y=hp,col=factor(cyl)))+geom_point()+
  labs(title="Scatter Plot MPG and HP")+ theme(plot.title = element_text(hjust=0.5))
 
#Scatterplot with smoothing
ggplot(data = mtcars,aes(x = wt, y = mpg)) + geom_point() + 
  stat_smooth(method = 'lm')+labs(title="Scatter Plot MPG and HP with Smoothing")+
  theme(plot.title = element_text(hjust=0.5))+
  xlab('Weight(1,000)') + ylab('MPG')

#Bar Chart
ggplot(data = mtcars,aes(x=cyl,fill=factor(gear)))+geom_bar()+
  labs(title="Histogram CYL by Gear")+ theme(plot.title = element_text(hjust=0.5))
 
#Bar Chart - Proportions
ggplot(data = mtcars,aes(x=cyl,fill=factor(gear)))+geom_bar(position = "fill")+
  labs(title="Histogram CYL by Gear (Proportion)")+ theme(plot.title = element_text(hjust=0.5))
  
#Boxplot
ggplot(data=mtcars, aes(factor(cyl), mpg))+ geom_boxplot(aes(fill = factor(cyl))) +
  labs(title="Boxplot Cyl vs mpg")+ theme(plot.title = element_text(hjust=0.5))

#Creating Side by Side Graphs

library(cowplot)

dodgeplot<-ggplot(data=mpg, aes(x = class, fill = drv)) + 
  geom_bar(position = "dodge")

fillplot<-ggplot(data=mpg, aes(x = class, fill = drv)) + 
  geom_bar(position = "fill")

plot_grid(dodgeplot, fillplot, labels = c('Dodge','Fill'),align="h")

